import { useNavigate, useParams, Link } from "react-router";
import { useEffect, useState } from "react";
import { notasApi } from "../utils/api";
import { Nota } from "../types/nota";
import { Button } from "../components/ui/button";
import { NotaStatusBadges } from "../components/NotaStatusBadges";
import { ArrowLeft, Printer, Pencil, Phone, MapPin, Clock, Mail, Download } from "lucide-react";
import * as htmlToImage from "html-to-image";
import { toast } from "sonner";
import { MaderaLogo } from "../components/MaderaLogo";

export function VerNotaPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [nota, setNota] = useState<Nota | null>(null);

  useEffect(() => {
    if (id) {
      notasApi.getById(id).then((notaEncontrada) => {
        setNota(notaEncontrada);
      }).catch(() => {
        navigate("/");
      });
    }
  }, [id, navigate]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadImage = async () => {
    const notaElement = document.getElementById('nota-para-imprimir');
    if (!notaElement) return;

    try {
      toast.loading("Generando imagen...", { id: "download-nota" });

      // Ocultar temporalmente los bordes para impresión en la imagen generada (opcional)
      notaElement.classList.remove('print:border-2');

      const dataUrl = await htmlToImage.toJpeg(notaElement, {
        quality: 0.95,
        backgroundColor: '#ffffff',
        pixelRatio: 2
      });

      // Restaurar estilos de clase
      notaElement.classList.add('print:border-2');

      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `Nota_Madera_Boutique_${nota?.numeroNota || 'Generica'}.jpg`;
      link.click();

      toast.success("Imagen descargada exitosamente", { id: "download-nota" });
    } catch (error) {
      console.error("Error generating image:", error);
      toast.error("Error al generar la imagen", { id: "download-nota" });
    }
  };

  const formatearFecha = (fechaISO: string) => {
    const date = new Date(fechaISO + "T00:00:00");
    const dia = date.getDate();
    const mes = date.getMonth() + 1;
    const anio = date.getFullYear().toString().slice(-2);
    return `${dia} | ${mes} | ${anio}`;
  };

  const totalAbonado = nota?.abonos?.reduce((sum, abono) => sum + abono.monto, 0) || 0;
  const saldoPendiente = (nota?.total || 0) - totalAbonado;

  if (!nota) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Cargando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Botones de acción - solo visible en pantalla */}
        <div className="mb-6 flex gap-4 print:hidden">
          <Button onClick={() => navigate("/")} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <Link to={`/editar/${nota.id}`}>
            <Button className="bg-green-600 hover:bg-green-700 text-white">
              <Pencil className="w-4 h-4 mr-2" />
              Editar
            </Button>
          </Link>
          <Button onClick={handleDownloadImage} className="bg-blue-600 hover:bg-blue-700 text-white">
            <Download className="w-4 h-4 mr-2" />
            Descargar
          </Button>
          <Button onClick={handlePrint} className="bg-gradient-to-r from-[#ff7908] to-[#ffac08] hover:from-[#ffac08] hover:to-[#ffe843] text-white">
            <Printer className="w-4 h-4 mr-2" />
            Imprimir
          </Button>
        </div>

        {/* Nota para imprimir/descargar */}
        <div id="nota-para-imprimir" className="bg-white border-4 border-[#ffac08] rounded-lg p-8 print:border-2">
          {/* Header */}
          <div className="flex items-start justify-between mb-6 pb-4 border-b-2 border-[#ffac08]">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-[#ff7908] to-[#ffac08] rounded-lg flex items-center justify-center p-2">
                <MaderaLogo className="w-full h-full text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-[#ff7908] tracking-wider">MADERA</h1>
                <h2 className="text-xl font-bold text-[#ff7908] tracking-widest">BOUTIQUE</h2>
                <p className="text-xs text-[#ffac08] mt-1">DETALLES EXCLUSIVOS Y CORTE LÁSER</p>
              </div>
            </div>

            <div className="text-right text-sm text-[#ff7908]">
              <div className="mb-2 space-y-1">
                <p className="font-semibold flex items-center justify-end gap-1">
                  <Phone className="w-3 h-3" /> (967) 678-04-63
                </p>
                <p className="font-semibold flex items-center justify-end gap-1">
                  <svg className="w-3 h-3 text-[#25D366] fill-current" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
                  </svg>
                  (961) 177-87-74
                </p>
              </div>
              <div className="mb-2 space-y-1">
                <p className="text-xs flex items-center justify-end gap-1">
                  <svg className="w-3 h-3 text-[#1877F2] fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                  /MaderaBoutique31
                </p>
                <p className="text-xs flex items-center justify-end gap-1">
                  <svg className="w-3 h-3 text-[#E1306C] fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                  </svg>
                  @Maderaboutique16
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-xs flex items-center justify-end gap-1">
                  <Mail className="w-3 h-3" /> maderaboutique31@outlook.com
                </p>
                <p className="text-xs flex items-center justify-end gap-1">
                  <Mail className="w-3 h-3" /> maderaboutique32@outlook.es
                </p>
              </div>
            </div>
          </div>

          <div className="text-xs text-[#ff7908] text-center mb-4 flex items-center justify-center gap-1">
            <MapPin className="w-3 h-3" />
            <p>José María Morelos #22. Col. Altejar. San Cristóbal de Las Casas, Chiapas.</p>
          </div>

          <div className="flex items-center gap-4 text-sm text-[#ff7908] mb-6">
            <div className="flex-1 flex items-start gap-2">
              <Clock className="w-4 h-4 mt-0.5" />
              <div>
                <p className="font-semibold mb-1">Lunes a Viernes:</p>
                <p className="text-xs">10 a 20 h.</p>
              </div>
            </div>
            <div className="flex-1 flex items-start gap-2">
              <Clock className="w-4 h-4 mt-0.5" />
              <div>
                <p className="font-semibold mb-1">Sábados</p>
                <p className="text-xs">10 a 15:00 h.</p>
              </div>
            </div>
          </div>

          {/* Fecha y Número */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gradient-to-br from-[#ff7908] to-[#ffac08] text-white p-4 rounded-lg text-center">
              <p className="font-bold mb-2">FECHA</p>
              <p className="text-2xl font-bold">{formatearFecha(nota.fecha)}</p>
            </div>
            <div className="bg-gradient-to-br from-[#ff7908] to-[#ffac08] text-white p-4 rounded-lg text-center">
              <p className="font-bold mb-2">NOTA NÚMERO</p>
              <p className="text-2xl font-bold">{nota.numeroNota}</p>
            </div>
          </div>

          {/* Cliente */}
          <div className="bg-gradient-to-br from-[#ff7908] to-[#ffac08] text-white p-4 rounded-lg mb-6">
            <h3 className="text-center font-bold mb-4">CLIENTE</h3>
            <div className="space-y-2">
              <p>
                <span className="font-semibold">Nombre:</span> {nota.clienteNombre}
              </p>
              {nota.clienteDomicilio && (
                <p>
                  <span className="font-semibold">Domicilio:</span> {nota.clienteDomicilio}
                </p>
              )}
              {nota.clienteTelefono && (
                <p>
                  <span className="font-semibold">Tel:</span> {nota.clienteTelefono}
                </p>
              )}
            </div>
          </div>

          {/* Estados */}
          <div className="mb-6 flex justify-center">
            <NotaStatusBadges
              terminada={nota.terminada}
              pagada={nota.pagada}
              entregada={nota.entregada}
              viaWhatsapp={nota.viaWhatsapp}
            />
          </div>

          {/* Imágenes de Referencia */}
          {nota.imagenesReferencia && nota.imagenesReferencia.length > 0 && (
            <div className="mb-6">
              <h3 className="text-[#ff7908] font-bold mb-3 text-center">IMÁGENES DE REFERENCIA</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {nota.imagenesReferencia.map((imagen, index) => (
                  <img
                    key={index}
                    src={imagen}
                    alt={`Referencia ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg border-2 border-[#ffac08]"
                  />
                ))}
              </div>
            </div>
          )}

          {/* Tabla de Items */}
          <div className="border-2 border-[#ff7908] rounded-lg overflow-hidden mb-6">
            <div className="bg-gradient-to-r from-[#ff7908] to-[#ffac08] text-white grid grid-cols-12 gap-2 p-3 font-bold text-center">
              <div className="col-span-2">CANT.</div>
              <div className="col-span-5">DESCRIPCIÓN</div>
              <div className="col-span-2">P. UNIT</div>
              <div className="col-span-3">IMPORTE</div>
            </div>

            <div className="divide-y divide-[#ffac08]">
              {nota.items.map((item) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 p-3 items-center">
                  <div className="col-span-2 text-center font-semibold">{item.cantidad}</div>
                  <div className="col-span-5">{item.descripcion}</div>
                  <div className="col-span-2 text-center">${item.precioUnitario.toFixed(2)}</div>
                  <div className="col-span-3 text-center font-semibold">${item.importe.toFixed(2)}</div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-[#fffb89] to-[#fffbc0] p-4 border-t-2 border-[#ff7908] grid grid-cols-2 gap-4">
              <div className="text-right">
                {totalAbonado > 0 ? (
                  <>
                    <p className="font-bold text-[#ff7908] mb-1">TOTAL ORIGINAL:</p>
                    <p className="font-bold text-[#ff7908] mb-1">ABONADO:</p>
                    <p className="text-xl font-bold text-red-600 mt-2">RESTA:</p>
                  </>
                ) : (
                  <p className="text-xl font-bold text-[#ff7908] mt-2">TOTAL:</p>
                )}
              </div>
              <div className="text-right pr-4">
                {totalAbonado > 0 ? (
                  <>
                    <p className="font-bold text-gray-500 line-through mb-1">${nota.total.toFixed(2)}</p>
                    <p className="font-bold text-green-600 mb-1">-${totalAbonado.toFixed(2)}</p>
                    <p className="text-3xl font-bold text-red-600 mt-2">${saldoPendiente.toFixed(2)}</p>
                  </>
                ) : (
                  <p className="text-3xl font-bold text-[#ff7908] mt-1">${nota.total.toFixed(2)}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:border-2 {
            border-width: 2px !important;
          }
        }
      `}</style>
    </div>
  );
}